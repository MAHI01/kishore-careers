package com.order.service.item.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.order.service.item.model.OrderItamService;


public interface OrderItamServiceRepository extends JpaRepository<OrderItamService, Integer> {

}
