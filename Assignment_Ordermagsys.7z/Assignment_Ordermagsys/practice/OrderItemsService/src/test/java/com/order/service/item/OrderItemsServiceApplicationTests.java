package com.order.service.item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderItemsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
